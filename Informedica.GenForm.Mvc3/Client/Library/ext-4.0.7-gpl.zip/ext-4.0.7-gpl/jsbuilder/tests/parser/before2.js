//<debug>
alert('Debug here');
//<else>
alert('Not debug here');
//</debug>

//<deprecated since="1.0">
alert("Deprecated since 1.0")
//</deprecated>