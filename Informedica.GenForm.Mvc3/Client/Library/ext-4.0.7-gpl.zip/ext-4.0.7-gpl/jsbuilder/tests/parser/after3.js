    if (someCondition) {
        throw new Error("Some error");
    }

    if (someCondition) {
        console.warn("Some warning");
    }


